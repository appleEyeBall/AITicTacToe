package util;

public class Util {
    public static String instructionText = "This whole game works by clicking one button the 'Start' button. " +
            "Two computer opponents are playing against each other and you " +
            "are essentially “watching” them play games of tic tac toe. You can pick levels for each player with expert " +
            "being the most probable to win and novice being the least";

    public static String initialBoardValue = "b b b b b b b b b";
    public static String infoInitial = "Choose number of games and players abilities, then Press 'Start' to begin";
    public static String infoDuring = "Sit tight and watch players compete";
}
